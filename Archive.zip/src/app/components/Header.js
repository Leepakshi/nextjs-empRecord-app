"use client";

import { signOut } from "next-auth/react";
import Link from "next/link";

export default function Header() {
  return (
    <header>
      <Link href="/">
        <h2 style={{ margin: 0 }}>My App</h2>
      </Link>

      <button
        onClick={() => signOut({ callbackUrl: "/login" })}
        style={{
          backgroundColor: "#ef4444",
          color: "white",
          border: "none",
          borderRadius: "4px",
          padding: "8px 16px",
          cursor: "pointer",
        }}
      >
        Logout
      </button>
    </header>
  );
}
