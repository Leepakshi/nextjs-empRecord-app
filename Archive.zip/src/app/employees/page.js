export default function EmployeesListPage() {
  return <h1 className="text-2xl font-bold">All Employees</h1>;
}
