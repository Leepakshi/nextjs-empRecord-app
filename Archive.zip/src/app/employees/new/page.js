export default function NewEmployeePage() {
  return <h1 className="text-2xl font-bold">Create New Employee</h1>;
}
