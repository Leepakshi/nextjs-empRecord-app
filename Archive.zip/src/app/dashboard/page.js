// app/dashboard/page.js
import Header from "../components/Header";
export default function DashboardPage() {
  const handleLogout = () => {
    signOut({ callbackUrl: "/login" }); // Redirect to login after logout
  };
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Welcome to the Dashboard!</h2>
    </div>
  );
}
